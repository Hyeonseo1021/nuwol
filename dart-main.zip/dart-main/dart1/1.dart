import 'dart:io';

void main() {
  for (int i = 0; i < 5; i++) {
    stdout.write("* "); // 별 출력
  }
  print(""); // 줄 바꿈
}
